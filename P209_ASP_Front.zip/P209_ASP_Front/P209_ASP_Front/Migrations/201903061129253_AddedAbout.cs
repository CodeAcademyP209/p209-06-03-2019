namespace P209_ASP_Front.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedAbout : DbMigration
    {
        public override void Up()
        {
            RenameTable(name: "dbo.Headers", newName: "Header");
            CreateTable(
                "dbo.About",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Title = c.String(nullable: false, maxLength: 100),
                        ContentUp = c.String(nullable: false, maxLength: 250),
                        ContentDown = c.String(nullable: false, maxLength: 250),
                        Image = c.String(maxLength: 300),
                    })
                .PrimaryKey(t => t.Id);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.About");
            RenameTable(name: "dbo.Header", newName: "Headers");
        }
    }
}
