namespace P209_ASP_Front.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using P209_ASP_Front.Models;

    internal sealed class Configuration : DbMigrationsConfiguration<P209_ASP_Front.DAL.EventreContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(P209_ASP_Front.DAL.EventreContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data.

            context.Headers.AddOrUpdate(h => new { h.SupTitle, h.Title, h.DatePlace },
                new Header { SupTitle = "The countdown is finished!", Title = "<h1>Business</h1><h2>Conference 2017</h2>", DatePlace = "02-05 July 2017 California", Image = "background/homepage-one-banner.jpg" }
            );

            context.About.AddOrUpdate(h => new { h.Title, h.ContentUp, h.ContentDown },
               new About {
                   Title = "About The <span class=\"alternate\">Eventre</span>",
                   ContentUp = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusm tempor incididunt ut labore dolore magna aliqua enim ad minim veniam quis nostrud exercitation ullamco.",
                   ContentDown = "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmtempor incididunt ut labore et dolore magna aliq enim ad minim veniam quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea.",
                   Image = "speakers/featured-speaker.jpg"
               }
           );

            context.Speakers.AddOrUpdate(s => new { s.Fullname, s.Profession },
                new Speaker
                {
                    Fullname = "Johnathan Franco",
                    Profession = "Project Manager",
                    Image = "speakers/speaker-one.jpg",
                    ImageThumb = "speakers/speaker-thumb-one.jpg",
                    Facebook = "asdf",
                    Twitter = "asdf",
                    LinkedIn = "asdf",
                    Pinterest = "asdf"
                },
                new Speaker
                {
                    Fullname = "Johnathan Franco 1",
                    Profession = "Project",
                    Image = "speakers/speaker-two.jpg",
                    ImageThumb = "speakers/speaker-thumb-two.jpg",
                    Facebook = "asdf",
                    Twitter = "asdf",
                    LinkedIn = "asdf",
                    Pinterest = "asdf"
                },
                new Speaker
                {
                    Fullname = "Johnathan Franco 2",
                    Profession = "Manager",
                    Image = "speakers/speaker-three.jpg",
                    ImageThumb = "speakers/speaker-thumb-three.jpg",
                    Facebook = "asdf",
                    Twitter = "asdf",
                    LinkedIn = "asdf",
                    Pinterest = "asdf"
                },
                new Speaker
                {
                    Fullname = "Johnathan Franco 3",
                    Profession = "Project Manager 1",
                    Image = "speakers/speaker-four.jpg",
                    ImageThumb = "speakers/speaker-thumb-four.jpg",
                    Facebook = "asdf",
                    Twitter = "asdf",
                    LinkedIn = "asdf",
                    Pinterest = "asdf"
                },
                new Speaker
                {
                    Fullname = "Johnathan Franco 4",
                    Profession = "Project Manager",
                    Image = "speakers/speaker-five.jpg",
                    ImageThumb = "speakers/speaker-thumb-five.jpg",
                    Facebook = "asdf",
                    Twitter = "asdf",
                    LinkedIn = "asdf",
                    Pinterest = "asdf"
                },
                new Speaker
                {
                    Fullname = "Johnathan Franco 5",
                    Profession = "Project Manager",
                    Image = "speakers/speaker-six.jpg",
                    ImageThumb = "speakers/speaker-thumb-six.jpg",
                    Facebook = "asdf",
                    Twitter = "asdf",
                    LinkedIn = "asdf",
                    Pinterest = "asdf"
                });


            context.Events.AddOrUpdate(
                new Event { Day = DateTime.Now.AddDays(-1) },
                new Event { Day = DateTime.Now }
            );

            context.Talks.AddOrUpdate(
                t => new { t.EventId, t.SpeakerId, t.Subject },
                new Talk { Time = new DateTime(2019, 03, 20, 9, 0, 0), Subject = "Introduction to Wp", SpeakerId = 1, EventId = 1, Venue = "Auditorium A" },
                new Talk { Time = new DateTime(2019, 03, 20, 11, 20, 0), Subject = "Principle of Wp", SpeakerId = 2, EventId = 1, Venue = "Auditorium B" },
                new Talk { Time = new DateTime(2019, 03, 20, 15, 0, 0), Subject = "Wp Requirements", SpeakerId = 3, EventId = 1, Venue = "Auditorium C" },
                new Talk { Time = new DateTime(2019, 03, 20, 17, 0, 0), Subject = "Useful tips for Wp", SpeakerId = 4, EventId = 1, Venue = "Auditorium D" },
                new Talk { Time = new DateTime(2019, 03, 20, 10, 40, 0), Subject = "Wp Requirements", SpeakerId = 5, EventId = 2, Venue = "Auditorium A" },
                new Talk { Time = new DateTime(2019, 03, 20, 12, 0, 0), Subject = "Introduction to Wp", SpeakerId = 1, EventId = 2, Venue = "Auditorium B" },
                new Talk { Time = new DateTime(2019, 03, 20, 14, 15, 0), Subject = "Principle of Wp", SpeakerId = 3, EventId = 2, Venue = "Auditorium C" },
                new Talk { Time = new DateTime(2019, 03, 20, 17, 0, 0), Subject = "Useful tips for Wp", SpeakerId = 4, EventId = 2, Venue = "Auditorium D" }
            );
        }
    }
}
