namespace P209_ASP_Front.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddedEvents : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Event",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Day = c.DateTime(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Talk",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Time = c.DateTime(nullable: false),
                        Subject = c.String(),
                        Venue = c.String(),
                        SpeakerId = c.Int(nullable: false),
                        EventId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id)
                .ForeignKey("dbo.Event", t => t.EventId, cascadeDelete: true)
                .ForeignKey("dbo.Speaker", t => t.SpeakerId, cascadeDelete: true)
                .Index(t => t.SpeakerId)
                .Index(t => t.EventId);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Talk", "SpeakerId", "dbo.Speaker");
            DropForeignKey("dbo.Talk", "EventId", "dbo.Event");
            DropIndex("dbo.Talk", new[] { "EventId" });
            DropIndex("dbo.Talk", new[] { "SpeakerId" });
            DropTable("dbo.Talk");
            DropTable("dbo.Event");
        }
    }
}
