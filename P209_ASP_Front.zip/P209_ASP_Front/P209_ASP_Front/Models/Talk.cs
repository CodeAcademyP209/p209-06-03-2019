﻿using System;

namespace P209_ASP_Front.Models
{
    public class Talk
    {
        public int Id { get; set; }

        public DateTime Time { get; set; }
        public string Subject { get; set; }
        public string Venue { get; set; }

        public int SpeakerId { get; set; }
        public int EventId { get; set; }

        public virtual Speaker Speaker { get; set; }
        public virtual Event Event { get; set; }
    }
}